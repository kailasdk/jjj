package com.in28minutes.domain;

public enum Priority {
	LOW, MEDIUM, HIGH
}
